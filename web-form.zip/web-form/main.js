$('.ui.checkbox')
  .checkbox()
;